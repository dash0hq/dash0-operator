# Troubleshooting

This guide covers common troubleshooting procedures for the Dash0 operator.

## Table of Contents

- [Create Heap Profiles](#create-heap-profiles)
  - [Operator Manager Heap Profile](#operator-manager-heap-profile)
  - [Collector Daemonset Heap Profile](#collector-daemonset-heap-profile)
  - [Collector Deployment Heap Profile](#collector-deployment-heap-profile)
  - [SignalControl Collector Heap Profile](#signalcontrol-collector-heap-profile)
  - [Edge Proxy Heap Profile](#edge-proxy-heap-profile)
  - [Auxiliary Container Heap Profiles](#auxiliary-container-heap-profiles)

## Create Heap Profiles

The instructions in this section are mainly meant to be used in a shared troubleshooting session with Dash0 support.

### Operator Manager Heap Profile

To get a heap profile from the operator manager container:

1. Deploy the operator manager with the additional Helm value `operator.pprofPort=1777`.
2. Take note of the namespace the operator is deployed in (default: `dash0-system`).
3. Run `kubectl get pod -n <operator-namespace> -l app.kubernetes.io/component=controller` to get the name of the
   operator manager pod (usually something like `dash0-operator-controller-xxxxxxxxx-xxxxx`, but the name depends on the
   Helm release name).
4. Using the information from the previous two steps, run
   `kubectl port-forward -n <operator-namespace> <operator-manager-pod-name> 1777`.
5. In a separate shell, while the `kubectl port-forward` command from the previous step is still running, run
   `curl http://localhost:1777/debug/pprof/heap > dash0-operator-manager-heap.out`.
6. Terminate the `kubectl port-forward` command.
7. Redeploy the operator without the Helm setting `operator.pprofPort=1777`.

### Collector Daemonset Heap Profile

To get a heap profile from a OpenTelemetry collector daemonset container:

1. Deploy the operator manager with the additional Helm value `operator.collectors.enablePprof=true`.
   Note that this will restart the collector pods.
2. Take note of the namespace the operator is deployed in (default: `dash0-system`).
3. Run `kubectl top pod -n <operator-namespace> -l app.kubernetes.io/component=agent-collector` to get the name of a
   collector pod that has high memory usage (usually something like
   `dash0-operator-opentelemetry-collector-agent-daemonset-xxxxx`, but the name depends on the Helm release name).
4. Using the information from the previous two steps, run
   `kubectl port-forward -n <operator-namespace> <collector-daemonset-pod-name> 1777`.
5. In a separate shell, while the `kubectl port-forward` command from the previous step is still running, run
   `curl http://localhost:1777/debug/pprof/heap > dash0-daemonset-collector.out`.
6. Terminate the `kubectl port-forward` command.
7. Redeploy the operator without the Helm setting `operator.collectors.enablePprof=true`.

### Collector Deployment Heap Profile

To get a heap profile from a OpenTelemetry collector deployment container:

* Follow the same steps as for the collector daemonset, but use
  `-l app.kubernetes.io/component=cluster-metrics-collector` in step (3).

### SignalControl Collector Heap Profile

To get a heap profile from the SignalControl collector (only present when SignalControl Edge is enabled):

* Follow the same steps as for the collector daemonset, but use
  `-l app.kubernetes.io/component=signal-control-collector` in step (3).

### Edge Proxy Heap Profile

To get a heap profile from the Edge Proxy (only present when SignalControl is enabled):

1. Deploy the operator manager with the additional Helm value `operator.signalControl.edgeProxy.enablePprof=true`.
   Note that this will restart the Edge Proxy pods.
2. Take note of the namespace the operator is deployed in (default: `dash0-system`).
3. Run `kubectl top pod -n <operator-namespace> -l app.kubernetes.io/component=edge-proxy` to get the name of an Edge
   Proxy pod that has high memory usage.
4. Using the information from the previous two steps, run
   `kubectl port-forward -n <operator-namespace> <edge-proxy-pod-name> 8012`.
5. In a separate shell, while the `kubectl port-forward` command from the previous step is still running, run
   `curl http://localhost:8012/debug/pprof/heap > dash0-edge-proxy.out`.
6. Terminate the `kubectl port-forward` command.
7. Redeploy the operator without the Helm setting `operator.signalControl.edgeProxy.enablePprof=true`.

### Auxiliary Container Heap Profiles

The Helm value `operator.collectors.enablePprof=true` also enables pprof in the auxiliary containers of the
collector pods.
The pprof ports are as follows:

| Container                 | Port   | Present in                                                     |
|---------------------------|--------|----------------------------------------------------------------|
| `opentelemetry-collector` | `1777` | daemonset, cluster metrics deployment, SignalControl collector |
| `configuration-reloader`  | `1778` | daemonset, cluster metrics deployment, SignalControl collector |
| `filelog-offset-sync`     | `1779` | daemonset                                                      |

To get a heap profile from one of the auxiliary containers, follow the same steps as for the collector daemonset, but
use the port of the container in question in steps (4) and (5), for example
`kubectl port-forward -n <operator-namespace> <collector-daemonset-pod-name> 1778` and
`curl http://localhost:1778/debug/pprof/heap > dash0-configuration-reloader.out`.

## Getting Help

For additional help:
- Review the operator logs: `kubectl logs -n dash0-system -l app.kubernetes.io/component=controller`
- Contact Dash0 support at support@dash0.com

## Related Documentation

- [Platform Specific](platform-specific.md) - Platform-specific notes that may help troubleshoot issues
- [Configuration](configuration.md) - Verify your configuration settings
